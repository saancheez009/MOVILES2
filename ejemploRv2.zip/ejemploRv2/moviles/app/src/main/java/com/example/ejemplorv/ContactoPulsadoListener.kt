package com.example.ejemplorv

interface ContactoPulsadoListener {
    fun contactoPulsado(contacto: Contacto){

    }
    fun contactoPulsadoInicial(contacto: Contacto) {

    }
}